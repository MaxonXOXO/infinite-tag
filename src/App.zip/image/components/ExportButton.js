import React from 'react';

const ExportButton = ({ annotations, imageId }) => {
  const handleExport = () => {
    if (!annotations || annotations.length === 0) {
      alert('No annotations to export!');
      return;
    }

    const exportData = {
      exportDate: new Date().toISOString(),
      imageId: imageId || 'local-image',
      annotations: annotations
    };

    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `annotations-${imageId || 'export'}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <button 
      className="export-btn" 
      onClick={handleExport}
      disabled={!annotations || annotations.length === 0}
    >
      Export Annotations
    </button>
  );
};

// Make sure this line is at the end:
export default ExportButton;