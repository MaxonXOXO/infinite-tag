import React, { useRef, useEffect, useState } from 'react';

const AnnotationCanvas = ({ 
  image, 
  annotations, 
  setAnnotations, 
  selectedTool,
  currentAnnotation,
  setCurrentAnnotation 
}) => {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastPanPoint, setLastPanPoint] = useState({ x: 0, y: 0 });
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });

  // Initialize canvas size when image loads
  useEffect(() => {
    if (image && canvasRef.current) {
      const container = containerRef.current;
      const maxWidth = container.clientWidth - 40;
      const maxHeight = window.innerHeight - 200;
      
      let width = image.naturalWidth;
      let height = image.naturalHeight;
      
      // Scale down if image is larger than container
      if (width > maxWidth || height > maxHeight) {
        const ratio = Math.min(maxWidth / width, maxHeight / height);
        width *= ratio;
        height *= ratio;
      }
      
      setCanvasSize({ width, height });
      setScale(1);
      setOffset({ x: 0, y: 0 });
    }
  }, [image]);

  // Get accurate mouse position accounting for scale and offset
  const getMousePos = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    
    // Get raw mouse position relative to canvas
    const rawX = e.clientX - rect.left;
    const rawY = e.clientY - rect.top;
    
    // Convert to image coordinates
    const x = (rawX - offset.x) / scale;
    const y = (rawY - offset.y) / scale;
    
    return { x, y };
  };

  // Zoom with mouse wheel
  const handleWheel = (e) => {
    e.preventDefault();
    const zoomIntensity = 0.1;
    const wheel = e.deltaY < 0 ? 1 : -1;
    const zoom = Math.exp(wheel * zoomIntensity);
    
    setScale(prevScale => {
      const newScale = prevScale * zoom;
      return Math.min(Math.max(0.1, newScale), 5); // Limit scale between 0.1x and 5x
    });
  };

  // Handle mouse down for drawing and panning
  const handleMouseDown = (e) => {
    const pos = getMousePos(e);
    
    // Middle mouse button for panning
    if (e.button === 1) {
      e.preventDefault();
      setIsPanning(true);
      setLastPanPoint({ x: e.clientX, y: e.clientY });
      return;
    }
    
    // Left mouse button for drawing
    if (e.button === 0) {
      if (selectedTool === 'select') return;
      
      setIsDrawing(true);
      setStartPos(pos);
      
      // Generate sequential annotation ID
      const nextId = (annotations.length + 1).toString();
      
      const newAnnotation = {
        id: nextId,
        type: selectedTool,
        imageId: image.id,
        points: selectedTool === 'polygon' ? [pos] : [],
        x: pos.x,
        y: pos.y,
        width: 0,
        height: 0,
        color: '#ff0000',
        fill: 'rgba(255, 0, 0, 0.1)'
      };
      
      setCurrentAnnotation(newAnnotation);
    }
  };

  const handleMouseMove = (e) => {
    // Handle panning
    if (isPanning) {
      const deltaX = e.clientX - lastPanPoint.x;
      const deltaY = e.clientY - lastPanPoint.y;
      
      setOffset(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
      
      setLastPanPoint({ x: e.clientX, y: e.clientY });
      return;
    }
    
    if (!isDrawing || !currentAnnotation) return;
    
    const pos = getMousePos(e);
    
    if (selectedTool === 'rectangle') {
      const updatedAnnotation = {
        ...currentAnnotation,
        width: pos.x - startPos.x,
        height: pos.y - startPos.y
      };
      setCurrentAnnotation(updatedAnnotation);
    } else if (selectedTool === 'point') {
      // For points, update position while dragging
      const updatedAnnotation = {
        ...currentAnnotation,
        x: pos.x,
        y: pos.y
      };
      setCurrentAnnotation(updatedAnnotation);
    }
  };

  const handleMouseUp = (e) => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }
    
    if (!isDrawing || !currentAnnotation) return;
    
    const pos = getMousePos(e);
    
    if (selectedTool === 'polygon') {
      // For polygon, add point on click (but don't finish yet)
      const updatedPoints = [...currentAnnotation.points, pos];
      const updatedAnnotation = {
        ...currentAnnotation,
        points: updatedPoints
      };
      setCurrentAnnotation(updatedAnnotation);
    } else if (selectedTool === 'point') {
      // For point, finalize the position
      const finalAnnotation = {
        ...currentAnnotation,
        x: pos.x,
        y: pos.y
      };
      setAnnotations(prev => [...prev, finalAnnotation]);
      setCurrentAnnotation(null);
    } else if (selectedTool === 'rectangle') {
      // For rectangle, only finalize if it has reasonable size
      const minSize = 5;
      if (Math.abs(pos.x - startPos.x) > minSize && Math.abs(pos.y - startPos.y) > minSize) {
        const finalAnnotation = {
          ...currentAnnotation,
          width: pos.x - startPos.x,
          height: pos.y - startPos.y
        };
        setAnnotations(prev => [...prev, finalAnnotation]);
      }
      setCurrentAnnotation(null);
    }
    
    setIsDrawing(false);
  };

  // Finish polygon with double click
  const handleDoubleClick = (e) => {
    if (selectedTool === 'polygon' && currentAnnotation && currentAnnotation.points.length >= 3) {
      setAnnotations(prev => [...prev, currentAnnotation]);
      setCurrentAnnotation(null);
    }
  };

  // Keyboard events for spacebar panning
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.code === 'Space' && !isPanning) {
        e.preventDefault();
        setIsPanning(true);
        if (canvasRef.current) {
          canvasRef.current.style.cursor = 'grabbing';
        }
      }
    };

    const handleKeyUp = (e) => {
      if (e.code === 'Space') {
        setIsPanning(false);
        if (canvasRef.current) {
          canvasRef.current.style.cursor = selectedTool === 'select' ? 'default' : 'crosshair';
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isPanning, selectedTool]);

  // Update cursor based on tool and panning state
  useEffect(() => {
    if (canvasRef.current) {
      if (isPanning) {
        canvasRef.current.style.cursor = 'grabbing';
      } else {
        canvasRef.current.style.cursor = selectedTool === 'select' ? 'default' : 'crosshair';
      }
    }
  }, [isPanning, selectedTool]);

  // Draw everything
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !image) return;
    
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = canvasSize.width;
    canvas.height = canvasSize.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Save context
    ctx.save();
    
    // Apply transformations (scale and offset)
    ctx.translate(offset.x, offset.y);
    ctx.scale(scale, scale);
    
    // Draw image
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0, canvasSize.width, canvasSize.height);
      drawAnnotations(ctx);
    };
    img.src = image.url;
    
    // Restore context
    ctx.restore();
  }, [image, annotations, currentAnnotation, scale, offset, canvasSize]);

  const drawAnnotations = (ctx) => {
    // Draw saved annotations
    annotations.forEach(annotation => {
      drawSingleAnnotation(ctx, annotation);
    });
    
    // Draw current annotation in progress
    if (currentAnnotation) {
      drawSingleAnnotation(ctx, currentAnnotation);
      
      // Draw connecting lines for polygon while drawing
      if (currentAnnotation.type === 'polygon' && currentAnnotation.points.length > 0) {
        ctx.strokeStyle = '#00ff00';
        ctx.lineWidth = 2;
        ctx.setLineDash([5, 5]);
        
        ctx.beginPath();
        const firstPoint = currentAnnotation.points[0];
        ctx.moveTo(firstPoint.x, firstPoint.y);
        
        for (let i = 1; i < currentAnnotation.points.length; i++) {
          ctx.lineTo(currentAnnotation.points[i].x, currentAnnotation.points[i].y);
        }
        
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
  };

  const drawSingleAnnotation = (ctx, annotation) => {
    ctx.strokeStyle = annotation.color || '#ff0000';
    ctx.lineWidth = 2;
    ctx.fillStyle = annotation.fill || 'rgba(255, 0, 0, 0.1)';
    
    switch (annotation.type) {
      case 'rectangle':
        ctx.strokeRect(annotation.x, annotation.y, annotation.width, annotation.height);
        ctx.fillRect(annotation.x, annotation.y, annotation.width, annotation.height);
        break;
      case 'point':
        ctx.beginPath();
        ctx.arc(annotation.x, annotation.y, 5, 0, 2 * Math.PI);
        ctx.fill();
        break;
      case 'polygon':
        if (annotation.points && annotation.points.length > 0) {
          ctx.beginPath();
          ctx.moveTo(annotation.points[0].x, annotation.points[0].y);
          
          for (let i = 1; i < annotation.points.length; i++) {
            ctx.lineTo(annotation.points[i].x, annotation.points[i].y);
          }
          
          ctx.closePath();
          ctx.stroke();
          ctx.fill();
        }
        break;
      default:
        break;
    }
    
    // Draw annotation ID
    if (annotation.id) {
      ctx.fillStyle = '#000';
      ctx.font = '12px Arial';
      ctx.fillText(annotation.id, annotation.x, annotation.y - 10);
    }
  };

  // Reset zoom and pan
  const resetView = () => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  };

  if (!image) {
    return (
      <div className="annotation-canvas">
        <div className="no-image">Please upload an image to start annotating</div>
      </div>
    );
  }

  return (
    <div 
      className="annotation-canvas" 
      ref={containerRef}
      onWheel={handleWheel}
    >
      <div className="canvas-controls">
        <button onClick={resetView} className="control-btn">
          Reset View
        </button>
        <span className="zoom-info">Zoom: {Math.round(scale * 100)}%</span>
        <span className="tool-info">Tool: {selectedTool}</span>
      </div>
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onDoubleClick={handleDoubleClick}
        onContextMenu={(e) => e.preventDefault()} // Prevent right-click menu
      />
      <div className="canvas-hints">
        <p>• Scroll to zoom • Middle mouse button to pan • Double-click to finish polygon</p>
        <p>• For polygon: Click to add points, double-click to complete</p>
      </div>
    </div>
  );
};

export default AnnotationCanvas;